#!/usr/bin/php-cgi 
<?php
phpinfo();
?>